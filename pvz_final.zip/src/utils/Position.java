package utils;

import java.util.Objects;

public class Position {
	
	private int row;
	private int col;
	
	public Position(int row, int col) {
		this.row = row;
		this.col = col;
	}

	public int row() {
		return row;
	}
	
	public int column() {
		return col;
	}

	@Override
	public int hashCode() {
		return Objects.hash(col, row);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Position other = (Position) obj;
		return col == other.col && row == other.row;
	}

	public boolean isHorizontallyAligned(Position position) {
		return this.row == position.row();
	}

	public boolean isVerticallyAligned(Position position) {
		return this.col == position.column();	
	}
	
	public Position left() {
		Position pos = new Position(row, col-1);
		return pos;
	}
	
	public Position right() {
	    return new Position(row, col + 1);
	}

	public Position up() {
	    return new Position(row - 1, col);
	}

	public Position upLeft() {
	    return new Position(row - 1, col - 1);
	}

	public Position upRight() {
	    return new Position(row - 1, col + 1);
	}

	public Position down() {
	    return new Position(row + 1, col);
	}

	public Position downLeft() {
	    return new Position(row + 1, col - 1);
	}

	public Position downRight() {
	    return new Position(row + 1, col + 1);
	}
}