package pvz.logic;

import pvz.control.Level;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.Zombie;
import utils.Position;

public interface GameModel extends GameWorld {
    void reset();
    void update();
    void quit();
    boolean addPlant(Plant plant);
	boolean hasGameFinished();
	boolean playerQuits();
	boolean addZombie(Zombie zombie);
	boolean addPlantCheat(Plant plant);
	void reset(Level level, long seed);
	boolean addGameObject(String name, Position position);
	boolean addGameObjectForFree(String name, Position position);
	boolean catchObject(Position position);

}
