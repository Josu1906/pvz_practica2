package pvz.logic;

import java.util.Random;

import pvz.control.Level;
import pvz.logic.gameobjects.Zombie;
import pvz.logic.gameobjects.factories.ZombieFactory;
import utils.Position;


public class ZombiesManager {

	private Game game;
	private Level level;
	private Random rand;
	private int remainingZombies;

	public ZombiesManager(Game game, Level level, Random rand) {
		this.game = game;
		this.level = level;
		this.rand = rand;
		this.remainingZombies = level.getNumberOfZombies();
	}

	private boolean shouldAddZombie() {
		return rand.nextDouble() < level.getZombieFrequency();
	}
	
	
	private int randomZombieRow() {
		return rand.nextInt(Game.NUM_ROWS);
	}
	
	public boolean addZombie() {
		int row = randomZombieRow();
		return addZombie(row);
	}

	public boolean addZombie(int row) {
		Position p= game.newZombiePosition(row); 
		Zombie zombie = ZombieFactory.spawnRandomZombie(rand, game, p);
		
		boolean canAdd = getRemainingZombies() > 0 && shouldAddZombie();
		if(canAdd) {
			game.addGameObject(zombie);
			remainingZombies--;
		}
		return canAdd;
	}

	public int getRemainingZombies() {
		return remainingZombies;
	}
	
	public void update() {
		addZombie();
	}

}