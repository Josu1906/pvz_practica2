package pvz.logic.gameobjects.factories;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import pvz.logic.GameWorld;
import pvz.logic.gameobjects.BucketHeadZombie;
import pvz.logic.gameobjects.CommonZombie;
import pvz.logic.gameobjects.ExplosiveZombie;
import pvz.logic.gameobjects.SportyZombie;
import pvz.logic.gameobjects.Zombie;
import utils.Position;

public class ZombieFactory {

    private static final List<Zombie> AVAILABLE_ZOMBIES = Arrays.asList(
    	new CommonZombie(null, null),        new BucketHeadZombie(null, null),
        new SportyZombie(null, null),
        new ExplosiveZombie(null, null)
    );

    public static Zombie spawnZombie(String name, GameWorld game, Position position) {
        Zombie ret = null;
        for (Zombie zombie : AVAILABLE_ZOMBIES) {
            Zombie aux = zombie.create(name, game, position);

            if (aux != null) {
                ret = aux;
            }
        }

        return ret;
    }

    public static List<Zombie> getAvailableZombies() {
        return Collections.unmodifiableList(AVAILABLE_ZOMBIES);
    }
    
    public static Zombie spawnRandomZombie(Random rand, GameWorld game, Position position) {
        int index = rand.nextInt(AVAILABLE_ZOMBIES.size());
        Zombie prototype = AVAILABLE_ZOMBIES.get(index);

        return prototype.create(game, position);
    }
}