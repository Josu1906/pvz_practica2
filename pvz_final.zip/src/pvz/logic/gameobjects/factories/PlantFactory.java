package pvz.logic.gameobjects.factories;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import pvz.logic.GameWorld;
import pvz.logic.gameobjects.CherryBomb;
import pvz.logic.gameobjects.Peashooter;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.Sunflower;
import pvz.logic.gameobjects.WallNut;
import utils.Position;

public class PlantFactory {

	private static final List<Plant> AVAILABLE_PLANTS= Arrays.asList(
			new Sunflower(null,null),
			new Peashooter(null, null),
		    new WallNut(null, null),
		    new CherryBomb(null, null)
			);
	
	public static Plant spawnPlant(String name, GameWorld game, Position p) {
		Plant ret =null;
		for (Plant plant: AVAILABLE_PLANTS) {
			Plant aux= plant.create(name, game, p);

			if(aux!=null) {
				ret=aux;
			}
		}
		return ret;
	}
	
	public static List<Plant> getAvailablePlants() {
		return Collections.unmodifiableList(AVAILABLE_PLANTS);
	}

}
