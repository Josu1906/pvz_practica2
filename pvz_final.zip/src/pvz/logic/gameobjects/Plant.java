package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import utils.Position;

public abstract class Plant extends GameObject {
	private int strength;       
	private final int damage;
	private final int cost;
	
	protected Plant(Position position, GameWorld game, int strength, int damage, int cost) {
		super(position,game);
		this.strength=strength;
		this.damage=damage;
		this.cost=cost;
	}
	
	

	public abstract int getEndurance(); 
	
	@Override
	public boolean receiveZombieAttack(int damage) {
		boolean alive=isAlive(); 
		if (alive) {
			this.strength -= damage;
		}
		return alive;
	}

	public int getDamage() {
		return damage;
	}
	
	public int getCost() {
		return cost;
	}
	
	public int getStrength() {
		return strength;
	}
	
	public abstract String getName();

	public abstract String getSymbol();
	
	@Override
	public boolean isAlive() {
		return strength>0;
	}
	
	@Override
	public boolean receivePlantAttack(int damage) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onEnter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onExit() {
		// TODO Auto-generated method stub
		
	}
	
	public Plant create(String plantName, GameWorld game, Position position) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public abstract Plant copy(Position position, GameWorld game);
	
	@Override
	public boolean canBeSpawnedAt(Position position) {
	    return game.isInsideBoard(position) && game.isEmpty(position);
	}
}