package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.logic.actions.ExplosionAction;
import pvz.view.Messages;
import utils.Position;

public class ExplosiveZombie extends Zombie {

    private static final int EXPLOSION_DAMAGE = 3;
 
    private boolean killedByPlant;

    public ExplosiveZombie(Position position, GameWorld game) {
        super(position, game);
        killedByPlant = false;
    }
    
    @Override
    public Zombie create(GameWorld game, Position position) {
        return new ExplosiveZombie(position, game);
    }
    
    @Override
    public Zombie create(String name, GameWorld game, Position position) {
        Zombie result = null;

        if (getName().equalsIgnoreCase(name)
                || getSymbol().equalsIgnoreCase(name)) {
            result = new ExplosiveZombie(position, game);
        }

        return result;
    }
    
    @Override
    public Zombie copy(Position position, GameWorld game) {
        return new ExplosiveZombie(position, game);
    }
    
    @Override
    public boolean receivePlantAttack(int damage) {
        boolean accepted = super.receivePlantAttack(damage);

        if (accepted && !isAlive()) {
            killedByPlant = true;
        }

        return accepted;
    }

    @Override
    public void onExit() {
        super.onExit();

        if (killedByPlant) {
        	game.pushAction(new ExplosionAction(EXPLOSION_DAMAGE, false, getSurroundingPositions()));
        }
    }

    @Override
    public String getName() {
        return Messages.EXPLOSIVE_ZOMBIE_NAME;
    }

    @Override
    public String getSymbol() {
        return Messages.EXPLOSIVE_ZOMBIE_SYMBOL;
    }
    
    @Override
   	public String getDescription() {
   		 return Messages.ZOMBIE_DESCRIPTION.formatted(
   				getName(), MOVEMENT_INTERVAL,DAMAGE,ENDURANCE);
   	}
   	
   	@Override
   	public String getIcon() {
   	    return Messages.GAME_OBJECT_ICON.formatted(getSymbol(),getStrength());
   	}
   	
   	
}