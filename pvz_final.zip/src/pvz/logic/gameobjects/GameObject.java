package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import utils.Position;

public abstract class GameObject implements GameItem{
	protected GameWorld game;
	protected Position position;
	
	protected GameObject(Position position, GameWorld game) {
		this.position=position;
		this.game=game;
	}
	
	public Position getPosition() {
		return position;
	}
	
	public boolean isInPosition(Position other){
		return position.equals(other);
	}
	
	protected Position[] getSurroundingPositions() {
	    return new Position[] {
	        position.upLeft(),
	        position.up(),
	        position.upRight(),
	        position.left(),
	        position.right(),
	        position.downLeft(),
	        position.down(),
	        position.downRight()
	    };
	}
	
	public abstract String getIcon();
	
	public abstract String getDescription();
	
	public abstract boolean isAlive();
	
	public abstract void update();
	
	public abstract void onEnter();
	
	public abstract void onExit();
	
	public boolean catchObject(Position position) {
	    return false;
	}

	public boolean occupiesCell() {
		return true;
	}
	
	public abstract boolean canBeSpawnedAt(Position position);
} 
