package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;

public class CommonZombie extends Zombie {

    public CommonZombie(Position position, GameWorld game) {
        super(position, game);
    }
    
    @Override
    public String getName() {
        return Messages.ZOMBIE_NAME;
    }

    @Override
    public String getSymbol() {
        return Messages.ZOMBIE_SYMBOL;
    }
    
    @Override
    public String getDescription() {
        return Messages.ZOMBIE_DESCRIPTION.formatted(
                getName(),
                MOVEMENT_INTERVAL,
                DAMAGE,
                ENDURANCE);
    }
    
    @Override
	public String getIcon() {
	    return Messages.ZOMBIE_ICON.formatted(getStrength());
	}

    @Override
    public Zombie create(GameWorld game, Position position) {
        return new CommonZombie(position, game);
    }

    @Override
    public Zombie create(String name, GameWorld game, Position position) {
        Zombie result = null;

        if (getName().equalsIgnoreCase(name)
                || getSymbol().equalsIgnoreCase(name)) {
            result = new CommonZombie(position, game);
        }

        return result;
    }
    
    @Override
    public Zombie copy(Position position, GameWorld game) {
        return new CommonZombie(position, game);
    }
  
}