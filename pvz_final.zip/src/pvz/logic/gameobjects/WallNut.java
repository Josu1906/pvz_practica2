package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;

public class WallNut extends Plant {

	public static final int COST = 50;
    private static final int DAMAGE = 0;
    private static final int ENDURANCE = 10;
    
    public WallNut(Position position, GameWorld game) {
        super(position, game, ENDURANCE,DAMAGE, COST);
    }
    
    @Override
    public int getEndurance() {
        return ENDURANCE;
    }
    
    @Override
    public String getName() {
        return Messages.WALL_NUT_NAME;
    }

    @Override
    public String getSymbol() {
        return Messages.WALL_NUT_SYMBOL;
    }
    
    @Override
    public String getDescription() {
        return Messages.PLANT_DESCRIPTION.formatted(
                Messages.WALL_NUT_NAME_SHORTCUT,
                getCost(),
                getDamage(),
                getEndurance());
    }
	
	@Override
	public String getIcon() {
	    return Messages.GAME_OBJECT_ICON.formatted(getSymbol(), getStrength());
	}

	@Override
	public void update() {

	}
	

    @Override
    public Plant create(
            String name, GameWorld game, Position position) {

        Plant result = null;

        if (getName().equalsIgnoreCase(name) 
        		|| getSymbol().equalsIgnoreCase(name)) {
            result = new WallNut(position, game);
        }

        return result;
    }
    
    @Override
    public Plant copy(Position position, GameWorld game) {
        return new WallNut(position, game);
    }

}
