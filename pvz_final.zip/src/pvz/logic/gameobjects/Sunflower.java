package pvz.logic.gameobjects;
import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;


public class Sunflower extends Plant{
	
	private static final int GENERATION_INTERVAL = 3;
	
	public static final int COST = 20;
	private static final int DAMAGE = 0;
	private static final int ENDURANCE = 1;
	
	private int cyclesAlive;
	
	public Sunflower(Position position, GameWorld game) {
		super(position, game, ENDURANCE,DAMAGE,COST);
		this.cyclesAlive=0;
	}
	
	@Override
	public int getEndurance() {
	    return ENDURANCE;
	}
	
	@Override
	public void update() {
	    if (isAlive()) {
	        if (cyclesAlive > 0 && cyclesAlive % GENERATION_INTERVAL == 0) {
	            game.generateSun();
	        }
	        cyclesAlive++;
	    }
	}
	
	@Override
	public String getName() {
	    return Messages.SUNFLOWER_NAME;
	}

	@Override
	public String getSymbol() {
	    return Messages.SUNFLOWER_SYMBOL;
	}
	
	public int getCycle() {
		return cyclesAlive;
	}


	@Override
	public String getDescription() {
		 return Messages.SUNFLOWER_DESCRIPTION.formatted(COST,DAMAGE,ENDURANCE);
	}
	
	@Override
	public String getIcon() {
	    return Messages.SUNFLOWER_ICON.formatted(getStrength());
	}

	@Override
	public Plant create(String plantName, GameWorld game, Position position) {
		Plant plant=null;
		if(getName().equalsIgnoreCase(plantName) 
				|| getSymbol().equalsIgnoreCase(plantName) ) {
			plant= new Sunflower(position, game);
		}
		return plant;
	}
	
	@Override
	public Plant copy(Position position, GameWorld game) {
	    return new Sunflower(position, game);
	}

}
