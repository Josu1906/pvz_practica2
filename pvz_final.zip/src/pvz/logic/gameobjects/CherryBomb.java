package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.logic.actions.ExplosionAction;
import pvz.view.Messages;
import utils.Position;

public class CherryBomb extends Plant {

    public static final int COST = 50;
    private static final int DAMAGE = 10;
    private static final int ENDURANCE = 2;
    private static final int EXPLOSION_DELAY = 2;

    private int cyclesAlive;
    private boolean exploded;

	public CherryBomb(Position position, GameWorld game) {
	    super(position, game, ENDURANCE,DAMAGE, COST);
        cyclesAlive = 0;
        exploded = false;
	}
	
	@Override
	public int getEndurance() {
	    return ENDURANCE;
	}
	
	@Override
	public String getName() {
	    return Messages.CHERRY_BOMB_NAME;
	}

	@Override
	public String getSymbol() {
	    String symbol = Messages.CHERRY_BOMB_SYMBOL;

	    if (cyclesAlive == EXPLOSION_DELAY) {
	        symbol = symbol.toUpperCase();
	    }

	    return symbol;
	}
	
	@Override
	public String getIcon() {
	    return Messages.GAME_OBJECT_ICON.formatted(
	            getSymbol(), getStrength());
	}

	@Override
	public String getDescription() {
	    return Messages.PLANT_DESCRIPTION.formatted(
	            Messages.CHERRY_BOMB_NAME_SHORTCUT,
	            getCost(),
	            getDamage(),
	            getEndurance());
	}

	@Override
	public void update() {
		if (isAlive()) {
            if (cyclesAlive == EXPLOSION_DELAY) {
                exploded = true;
                game.pushAction(new ExplosionAction(DAMAGE, true, getSurroundingPositions()));      
            }
            cyclesAlive++;
        }
	}
	
	@Override
    public boolean isAlive() {
        return super.isAlive() && !exploded;
    }
	
	@Override
	public Plant create(String name, GameWorld game, Position position) {
		Plant result = null;

	    if (getName().equalsIgnoreCase(name) 
	    		|| getSymbol().equalsIgnoreCase(name)) {
	    	result = new CherryBomb(position,game);
	    }

	    return result;
	}
	
	@Override
	public Plant copy(Position position, GameWorld game) {
	    return new CherryBomb(position, game);
	}

}
