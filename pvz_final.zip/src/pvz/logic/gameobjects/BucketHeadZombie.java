package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;

public class BucketHeadZombie extends Zombie {

    private static final int ENDURANCE = 8;
    private static final int MOVEMENT_INTERVAL = 4;


    public BucketHeadZombie(Position position, GameWorld game) {
        super(position, game, ENDURANCE, MOVEMENT_INTERVAL);
    }
    
    @Override
    public Zombie create(GameWorld game, Position position) {
        return new BucketHeadZombie(position, game);
    }
    
    @Override
    public Zombie create(String name, GameWorld game, Position position) {
        Zombie result = null;

        if (getName().equalsIgnoreCase(name)
                || getSymbol().equalsIgnoreCase(name)) {
            result = new BucketHeadZombie(position, game);
        }
        return result;
    }
    
    @Override
    public Zombie copy(Position position, GameWorld game) {
        return new BucketHeadZombie(position, game);
    }

    @Override
	public String getDescription() {
		 return Messages.ZOMBIE_DESCRIPTION.formatted(
				 getName(), MOVEMENT_INTERVAL,DAMAGE,ENDURANCE);
	}
	
	@Override
	public String getIcon() {
	    return Messages.GAME_OBJECT_ICON.formatted(getSymbol(),getStrength());
	}
	
	@Override
	public String getName() {
	    return Messages.BUCKET_HEAD_ZOMBIE_NAME;
	}

	@Override
	public String getSymbol() {
	    return Messages.BUCKET_HEAD_ZOMBIE_SYMBOL;
	}
	
	
}