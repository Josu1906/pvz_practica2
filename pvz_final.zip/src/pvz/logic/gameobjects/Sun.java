package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;

public class Sun extends GameObject {

    private static final int LIFETIME = 10;
    public static final int VALUE = 10;

    private int remainingCycles;
    private boolean caught;

    public Sun(Position position, GameWorld game) {
        super(position, game);

        remainingCycles = LIFETIME +1;
        caught = false;
    }

    @Override
    public void update() {
        if (isAlive()) {
            remainingCycles--;
        }
    }

    @Override
    public boolean isAlive() {
        return remainingCycles > 0 && !caught;
    }

    @Override
    public String getIcon() {
        return Messages.GAME_OBJECT_ICON.formatted(Messages.SUN_SYMBOL,remainingCycles);
    }

    @Override
    public String getDescription() {
        return Messages.SUN_DESCRIPTION;
    }

    @Override
    public boolean receivePlantAttack(int damage) {
        return false;
    }

    @Override
    public boolean receiveZombieAttack(int damage) {
        return false;
    }

    @Override
    public void onEnter() {
    }

    @Override
    public void onExit() {
    }

    
    @Override
    public boolean catchObject(Position position) {
        boolean success = isAlive() && isInPosition(position);
        if (success) {
            caught = true;
            game.generateCoins(VALUE);
        }
        return success;
    }
    
    @Override
    public boolean occupiesCell() {
        return false;
    }
    
    @Override
    public boolean canBeSpawnedAt(Position position) {
        return game.isInsideBoard(position);
    }
}