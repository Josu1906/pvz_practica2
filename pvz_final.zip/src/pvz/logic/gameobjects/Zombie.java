package pvz.logic.gameobjects;

import pvz.logic.GameWorld;
import utils.Position;

public abstract class Zombie extends GameObject{
	
	protected final static int DAMAGE=1;
	protected static final int ENDURANCE = 5;
	protected static final int MOVEMENT_INTERVAL = 2;

    private int strength;
	private int cyclesAlive;
	
	private final int movementInterval;

	protected Zombie(Position position, GameWorld game) {
	    this(position, game, ENDURANCE, MOVEMENT_INTERVAL);
	}

	protected Zombie(Position position, GameWorld game, int endurance, int movementInterval) {
	    super(position, game);
	    this.strength = endurance;
	    this.movementInterval = movementInterval;
	    this.cyclesAlive = 0;
	}
	
	public abstract Zombie create(GameWorld game, Position position);

	public abstract Zombie create(String name, GameWorld game, Position position);
	
	public abstract String getName();

	public abstract String getSymbol();
	
   	public abstract String getDescription();
	
	public abstract String getIcon();
	
	public boolean isHorizontallyAligned(Position position) {
		return this.position.isHorizontallyAligned(position);
	}
	
	public boolean isVerticallyAligned(Position position) {
		return this.position.isVerticallyAligned(position);
	}
	
	@Override
	public boolean receivePlantAttack(int damage) {
		boolean alive=isAlive();
		if(alive) {
			strength-=damage;
		}
		return alive;
	}
	
	@Override
	public void update() {
	    if (isAlive()) {
	        Position ahead = position.left();

	        boolean clearPath = game.isEmpty(ahead);
	        boolean movementDue = cyclesAlive > 0
	                && cyclesAlive % movementInterval == 0;

	        if (clearPath && movementDue) {
	            position = ahead;
	            ahead = position.left();
	        }

	        game.zombieAttack(ahead, DAMAGE);

	        if (!movementDue || clearPath) {
	            cyclesAlive++;
	        }
	    }
	}
	
	@Override
	public boolean isAlive() {
		return strength>0;
	}
	
	public int getCol() {
		return position.column();
	}

	@Override
	public boolean receiveZombieAttack(int damage) {
		return false;
	}
	
	@Override
	public void onEnter() {
	    game.zombieEntered();
	}

	@Override
	public void onExit() {
	    game.zombieKilled();
	}
	
	protected int getStrength() {
	    return strength;
	}
	
	@Override
	public boolean canBeSpawnedAt(Position position) {
	    boolean validRow = position.row() >= 0 && position.row() < GameWorld.NUM_ROWS;
	    boolean entrance = position.column() == GameWorld.NUM_COLS;
	    boolean emptyCell = game.isInsideBoard(position) && game.isEmpty(position);

	    return validRow && (entrance || emptyCell);
	}
	
	public abstract Zombie copy(Position position, GameWorld game);
	
	
}
