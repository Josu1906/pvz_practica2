package pvz.logic.gameobjects;
import pvz.logic.GameWorld;
import pvz.view.Messages;
import utils.Position;


public class Peashooter extends Plant {
	
	public static final int COST = 50;
	private static final int DAMAGE = 1;
	private static final int ENDURANCE = 3;
	
	
	public Peashooter(Position position, GameWorld game) {
		super(position, game, ENDURANCE,DAMAGE, COST);
	}
	
	@Override
	public int getEndurance() {
	    return ENDURANCE;
	}
	
	@Override
	public void update() {
	    if (isAlive()) {
	        game.plantAttack(position, DAMAGE);
	    }
	}
	
	@Override
	public String getName() {
	    return Messages.PEASHOOTER_NAME;
	}

	@Override
	public String getSymbol() {
	    return Messages.PEASHOOTER_SYMBOL;
	}
	
	@Override
	public String getDescription() {
		 return Messages.PEASHOOTER_DESCRIPTION.formatted(COST,DAMAGE,ENDURANCE);
	}
	
	@Override
	public String getIcon() {
	    return Messages.PEASHOOTER_ICON.formatted(getStrength());
	}
	
	
	@Override
	public Plant create(String plantName, GameWorld game, Position position) {
		Plant plant=null;
		if(getName().equalsIgnoreCase(plantName) 
				|| getSymbol().equalsIgnoreCase(plantName) ) {
			plant= new Peashooter(position,game);
		}
		return plant;
	}
	
	@Override
	public Plant copy(Position position, GameWorld game) {
	    return new Peashooter(position, game);
	}

}