package pvz.logic;

import java.util.ArrayList;
import java.util.List;

import pvz.logic.gameobjects.GameItem;
import pvz.logic.gameobjects.GameObject;
import utils.Position;

public class GameObjectContainer {

    private List<GameObject> gameObjects;

    public GameObjectContainer() {
        gameObjects = new ArrayList<>();
    }
    
    public void add(GameObject object) {
        gameObjects.add(object);
        object.onEnter();
    }
    
    public void update() {
        int i = 0;

        while (i < gameObjects.size()) {
            GameObject object = gameObjects.get(i);

            if (object.isAlive()) {
                object.update();
            }
            i++;
        }
    }
    
    public boolean removeDead() {
        boolean removed = false;
        int i = 0;

        while (i < gameObjects.size()) {
            GameObject object = gameObjects.get(i);

            if (!object.isAlive()) {
                gameObjects.remove(i);
                object.onExit();
                removed = true;
            } else {
                i++;
            }
        }

        return removed;
    }
    
    public boolean isPositionEmpty(Position position) {
        return getGameItemInPosition(position) == null;
    }
    
    public GameItem getGameItemInPosition(Position position) {
        GameItem result = null;
        int i = 0;

        while (i < gameObjects.size() && result == null) {
            GameObject object = gameObjects.get(i);

            if (object.isAlive() && object.isInPosition(position) && object.occupiesCell()) {
                result = object;
            }
            i++;
        }
        return result;
    }
    
    public String positionToString(Position position) {
        StringBuilder result = new StringBuilder();
        boolean sunShown = false;

        for (GameObject object : gameObjects) {
            if (object.isAlive() && object.isInPosition(position)) {
                if (object.occupiesCell()) {
                    result.append(object.getIcon());
                } else if (!sunShown) {
                    result.append(object.getIcon());
                    sunShown = true;
                }
            }
        }

        return result.toString();
    }
    
    public int catchObject(Position position) {
        int collected = 0;

        for (GameObject object : gameObjects) {
            if (object.catchObject(position)) {
                collected++;
            }
        }

        return collected;
    }
    
    public boolean anyInColumn(int column) {
        boolean found = false;
        int i = 0;

        while (i < gameObjects.size() && !found) {
            GameObject object = gameObjects.get(i);
            if (object.isAlive() && object.getPosition().column() == column) {
                found = true;
            }
            i++;
        }

        return found;
    }
    
    
}