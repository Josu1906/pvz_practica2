package pvz.logic.actions;

import pvz.logic.GameWorld;
import utils.Position;

public class ExplosionAction implements GameAction {
	private int damage;
	private boolean isPlant;
	private Position[] positions;
	
	public ExplosionAction(int damage, boolean isPlant, Position[] positions) {
	    this.damage = damage;
	    this.isPlant = isPlant;
	    this.positions = positions;
	}
    
	@Override
	public void execute(GameWorld game) {
	    for (Position target : positions) {
            if (isPlant) {
                game.plantAttackInPosition(target, damage);
            } else {
                game.zombieAttack(target, damage);
            }
	    }
	}
}


