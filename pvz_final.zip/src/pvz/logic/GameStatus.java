package pvz.logic;

import utils.Position;

public interface GameStatus {
		
	int getCycles();
	int getCoins();
	boolean playerWins();
	boolean playerQuits();
	int getRemainingZombies();
	boolean doZombiesReachedTheHouse();
	boolean hasGameFinished();
	String positionToString(Position p);
	int getGeneratedCoins();
	int getCaughtCoins();
}