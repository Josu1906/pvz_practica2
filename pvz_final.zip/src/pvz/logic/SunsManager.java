package pvz.logic;


import pvz.logic.gameobjects.Sun;
import utils.Position;

public class SunsManager {

    private static final int GENERATION_INTERVAL = 5;

    private Game game;
    private int cycles;

    public SunsManager(Game game) {
        this.game = game;
        this.cycles = 0;
    }

    public void update() {
        if (cycles > 0 && cycles % GENERATION_INTERVAL == 0) {
            game.generateSun();
        }

        cycles++;
    }

    public void generateSun() {
    	Position position = game.randomPosition();
        Sun sun = new Sun(position,game);
        game.addGameObject(sun);
    }
}