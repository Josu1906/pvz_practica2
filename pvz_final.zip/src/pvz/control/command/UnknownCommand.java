package pvz.control.command;

import pvz.logic.GameModel;
import pvz.view.GameView;
import pvz.view.Messages;

public class UnknownCommand extends Command {

    public UnknownCommand() {
        super("", "", "", "");
    }

    @Override
    protected Command create(String[] words) {
        return new UnknownCommand();
    }

    @Override
    public void execute(GameModel game, GameView view) {
        view.showError(Messages.UNKNOWN_COMMAND);
    }
}