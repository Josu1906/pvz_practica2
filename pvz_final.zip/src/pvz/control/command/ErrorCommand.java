package pvz.control.command;

import pvz.logic.GameModel;
import pvz.view.GameView;

public class ErrorCommand extends Command {

    private final String message;

    public ErrorCommand(String message) {
        super("", "", "", "");
        this.message = message;
    }

    @Override
    protected Command create(String[] words) {
        return this;
    }

    @Override
    public void execute(GameModel game, GameView view) {
        view.showError(message);
    }
}