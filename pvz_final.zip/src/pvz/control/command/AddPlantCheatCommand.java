package pvz.control.command;

import pvz.logic.GameModel;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.factories.PlantFactory;
import pvz.view.GameView;
import pvz.view.Messages;
import utils.Position;

public class AddPlantCheatCommand extends Command {

    private String plantName;
    private Position position;

    public AddPlantCheatCommand() {
        super(
            Messages.COMMAND_CHEAT_PLANT_NAME,
            Messages.COMMAND_CHEAT_PLANT_SHORTCUT,
            Messages.COMMAND_CHEAT_PLANT_DETAILS,
            Messages.COMMAND_CHEAT_PLANT_HELP
        );
    }

    public AddPlantCheatCommand(String plantName, Position position) {
        this();
        this.plantName = plantName;
        this.position = position;
    }

    @Override
    public Command create(String[] words) {
        Command result;

        if (words.length < 4) {
            result = new ErrorCommand(Messages.COMMAND_PARAMETERS_MISSING);
        } else if (words.length > 4) {
            result = new ErrorCommand(Messages.INVALID_COMMAND);
        } else {
            int col = Integer.parseInt(words[2]);
            int row = Integer.parseInt(words[3]);

            result = new AddPlantCheatCommand(words[1], new Position(row, col));
        }
        return result;
    }

    @Override
    public void execute(GameModel game, GameView view) {
        Plant plant = PlantFactory.spawnPlant(plantName, game, position);

        if (plant == null) {
        	view.showError(Messages.INVALID_GAME_OBJECT);
        } else if (!game.addPlantCheat(plant)) {
        	view.showError(Messages.INVALID_POSITION);
        } else {
            game.update();
            view.showGame();
        }
    }
}