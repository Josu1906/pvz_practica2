package pvz.control.command;

import pvz.logic.GameModel;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.factories.PlantFactory;
import pvz.view.GameView;
import pvz.view.Messages;

public class ListPlantsCommand extends NoParamsCommand {
	
	public ListPlantsCommand() {
		super(Messages.COMMAND_LIST_PLANTS_NAME, 
				Messages.COMMAND_LIST_PLANTS_SHORTCUT, 
				Messages.COMMAND_LIST_PLANTS_DETAILS, 
				Messages.COMMAND_LIST_PLANTS_HELP);
	}

	@Override
	public void execute(GameModel game, GameView view) {
	    StringBuilder message = new StringBuilder();

	    for (Plant plant : PlantFactory.getAvailablePlants()) {
	        message.append(plant.getDescription())
	               .append(System.lineSeparator());
	    }

	    view.showMessage(message.toString());
	}
}