package pvz.control.command;

import pvz.logic.GameModel;
import pvz.logic.gameobjects.Zombie;
import pvz.logic.gameobjects.factories.ZombieFactory;
import pvz.view.GameView;
import pvz.view.Messages;

public class ListZombiesCommand extends NoParamsCommand {

    public ListZombiesCommand() {
        super(
            Messages.COMMAND_LIST_ZOMBIES_NAME,
            Messages.COMMAND_LIST_ZOMBIES_SHORTCUT,
            Messages.COMMAND_LIST_ZOMBIES_DETAILS,
            Messages.COMMAND_LIST_ZOMBIES_HELP
        );
    }

    @Override
    public void execute(GameModel game, GameView view) {
        StringBuilder message = new StringBuilder();

        for (Zombie zombie : ZombieFactory.getAvailableZombies()) {
            message.append(zombie.getDescription())
                   .append(System.lineSeparator());
        }

        view.showMessage(message.toString());
    }
}