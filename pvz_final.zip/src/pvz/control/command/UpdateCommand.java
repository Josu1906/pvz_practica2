package pvz.control.command;

import pvz.logic.GameModel;
import pvz.view.GameView;
import pvz.view.Messages;

public class UpdateCommand extends NoParamsCommand {

	public UpdateCommand() {
		super(Messages.COMMAND_UPDATE_NAME,
				Messages.COMMAND_UPDATE_SHORTCUT, 
				Messages.COMMAND_UPDATE_DETAILS, 
				Messages.COMMAND_UPDATE_HELP);
	}

	@Override
	public void execute(GameModel game, GameView view) {
		 game.update();
		 view.showGame();
	}
	
	@Override
	protected boolean matchCommand(String c) {
	    return c.isEmpty() || super.matchCommand(c);
	}

}
