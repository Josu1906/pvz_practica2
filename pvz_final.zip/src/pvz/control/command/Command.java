package pvz.control.command;

//import java.util.*;
import java.util.List;
import java.util.Arrays;

import pvz.logic.GameModel;
import pvz.view.GameView;

public abstract class Command {
	public String name = "";
	public String shorcut = "";
	public String details = "";
	public String help = "";
	
	protected static final List<Command> AVAILABLE_COMMANDS = Arrays.asList(
		      new AddPlantCommand(),
		      new AddZombieCommand(),
		      new AddPlantCheatCommand(),
		      new CatchCommand(),
		      new ListPlantsCommand(),
		      new ListZombiesCommand(),
		      new ResetCommand(),
		      new HelpCommand(),
		      new ExitCommand(),
		      new UpdateCommand()
		  );
	
	public Command(String name, String shorcut, String details, String help) {
		this.name = name;
		this.shorcut = shorcut;
		this.details = details;
		this.help = help;
	}
	
	protected boolean matchCommand(String c) {
		boolean ret = false;
		if((c.equalsIgnoreCase(name) || c.equalsIgnoreCase(shorcut)) ) {
			ret = true;
		}	
		
		return ret;	
	}
	
	protected abstract Command create(String[] c);
	
	public abstract void execute(GameModel game, GameView view);
	
	public static Command parse(String[] commandWords) {
		Command command = new UnknownCommand();
		
		for(Command c : AVAILABLE_COMMANDS) {
			 if (c.matchCommand(commandWords[0])) {
		            command = c.create(commandWords);
		        }
		}
		
		return command;
    }
	
	public String getDetails() {
	    return details;
	}

	public String getHelp() {
	    return help;
	}
	
	
	
}