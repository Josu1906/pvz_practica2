package pvz.control.command;

import pvz.logic.GameModel;
import pvz.logic.gameobjects.Zombie;
import pvz.logic.gameobjects.factories.ZombieFactory;
import pvz.view.GameView;
import pvz.view.Messages;
import utils.Position;

public class AddZombieCommand extends Command {

    private String zombieName;
    private Position position;

    public AddZombieCommand() {
        super(
            Messages.COMMAND_ADD_ZOMBIE_NAME,
            Messages.COMMAND_ADD_ZOMBIE_SHORTCUT,
            Messages.COMMAND_ADD_ZOMBIE_DETAILS,
            Messages.COMMAND_ADD_ZOMBIE_HELP
        );
    }

    public AddZombieCommand(String zombieName, Position position) {
        this();
        this.zombieName = zombieName;
        this.position = position;
    }

    @Override
    public Command create(String[] words) {
        Command result;

        if (words.length < 4) {
            result = new ErrorCommand(Messages.COMMAND_PARAMETERS_MISSING);
        } else if (words.length > 4) {
            result = new ErrorCommand(Messages.INVALID_COMMAND);
        } else {
            int col = Integer.parseInt(words[2]);
            int row = Integer.parseInt(words[3]);

            result = new AddZombieCommand(words[1], new Position(row, col));
        }
        return result;
    }

    @Override
    public void execute(GameModel game, GameView view) {
        Zombie zombie = ZombieFactory.spawnZombie(
                zombieName, game, position);

        if (zombie == null) {
            view.showError(Messages.INVALID_GAME_OBJECT);
        } else if (!game.isInsideBoard(position)|| !game.addZombie(zombie)) {
            view.showError(Messages.INVALID_POSITION);
        } else {
            game.update();
            view.showGame();
        }
    }
}