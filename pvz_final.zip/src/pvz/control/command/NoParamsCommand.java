package pvz.control.command;

import pvz.view.Messages;

public abstract class NoParamsCommand extends Command {
	
	public NoParamsCommand(String name, String shorcut, String details, String help) {
		super(name, shorcut, details, help);
	}
	
	@Override
	public Command create(String[] c) {
	    Command result;

	    if (c.length == 1) {
	        result = this;
	    } else {
	        result = new ErrorCommand(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);
	    }

	    return result;
	}
}