package pvz.control.command;

import pvz.logic.GameModel;
import pvz.view.GameView;
import pvz.view.Messages;
import utils.Position;

public class CatchCommand extends Command {

    private Position position;

    public CatchCommand() {
        super(
            Messages.COMMAND_CATCH_NAME,
            Messages.COMMAND_CATCH_SHORTCUT,
            Messages.COMMAND_CATCH_DETAILS,
            Messages.COMMAND_CATCH_HELP
        );
    }

    public CatchCommand(Position position) {
        this();
        this.position = position;
    }

    @Override
    public Command create(String[] words) {
        Command result;

        if (words.length < 3) {
            result = new ErrorCommand(Messages.COMMAND_PARAMETERS_MISSING);
        } else if (words.length > 3) {
            result = new ErrorCommand(Messages.INVALID_COMMAND);
        } else {
            int col = Integer.parseInt(words[1]);
            int row = Integer.parseInt(words[2]);

            result = new CatchCommand(new Position(row, col));
        }

        return result;
    }

    @Override
    public void execute(GameModel game, GameView view) {
        if (!game.isInsideBoard(position)) {
            view.showError(Messages.INVALID_POSITION);
        } else if (game.catchObject(position)) {
            view.showGame();
        } else {
            view.showError(
                    Messages.NO_CATCHABLE_IN_POSITION.formatted(
                            position.column(), position.row()));
        }
    }
}