package pvz.control.command;

import pvz.control.Level;
import pvz.logic.GameModel;
import pvz.view.GameView;
import pvz.view.Messages;

public class ResetCommand extends Command {

    private Level level;
    private long seed;
    private boolean hasNewConfiguration;

    public ResetCommand() {
        super(
            Messages.COMMAND_RESET_NAME,
            Messages.COMMAND_RESET_SHORTCUT,
            Messages.COMMAND_RESET_DETAILS,
            Messages.COMMAND_RESET_HELP
        );
        hasNewConfiguration = false;
    }

    public ResetCommand(Level level, long seed) {
        this();
        this.level = level;
        this.seed = seed;
        this.hasNewConfiguration = true;
    }

    @Override
    public Command create(String[] words) {
        Command result;

        if (words.length == 1) {
            result = new ResetCommand();
        } else if (words.length == 3) {
            Level level = Level.valueOfIgnoreCase(words[1]);

            if (level != null) {
                long seed = Long.parseLong(words[2]);
                result = new ResetCommand(level, seed);
            } else {
                result = new ErrorCommand(Messages.INVALID_COMMAND);
            }
        } else {
            result = new ErrorCommand(
                    Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);
        }

        return result;
    }

    @Override
    public void execute(GameModel game, GameView view) {
        if (hasNewConfiguration) {
            game.reset(level, seed);
        } else {
            game.reset();
        }
        view.showGame();
    }
}