package pvz.control.command;

import pvz.logic.GameModel;
import pvz.view.GameView;
import pvz.view.Messages;

public class HelpCommand extends NoParamsCommand {

	
	public HelpCommand() {
		super(Messages.COMMAND_HELP_NAME, 
				Messages.COMMAND_HELP_SHORTCUT, 
				Messages.COMMAND_HELP_DETAILS, 
				Messages.COMMAND_HELP_HELP);
	}

	@Override
	public void execute(GameModel game, GameView view) {
	    StringBuilder message = new StringBuilder(
	            Messages.HELP_AVAILABLE_COMMANDS);

	    for (Command command : AVAILABLE_COMMANDS) {
	        message.append(System.lineSeparator())
	               .append(command.getDetails())
	               .append(Messages.HELP_DETAILS_COMMAND_HELP_SEPARATOR)
	               .append(command.getHelp());
	    }

	    view.showMessage(message.toString());
	}
}
