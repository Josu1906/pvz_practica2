package pvz.control;

import pvz.control.command.Command;
import pvz.logic.Game;
import pvz.logic.GameModel;
import pvz.view.GamePrinter;
import pvz.view.GameView;


public class Controller {

	private final GameModel game;
	private final GameView view;

	public Controller(Game game) {
		this.game = game;
		this.view = new GamePrinter(game);
	}

	public void run() {
		view.showGame();

		while(!game.hasGameFinished() && !game.playerQuits()) {
			String[] str = this.view.getPrompt();
			Command command=Command.parse(str);
			
			if(command!=null) {
				command.execute(game,view);
			}
				
		}
		view.showEndMessage();

	}
}