package pvz.logic;

import utils.Position;

public interface GameStatus {
		
	int getCycles();
	int getCoins();
	int getRemainingZombies();
	int getGeneratedCoins();
	int getCaughtCoins();

	String positionToString(Position p);

	boolean playerWins();
	boolean playerQuits();
	boolean doZombiesReachedTheHouse();
	boolean hasGameFinished();
}