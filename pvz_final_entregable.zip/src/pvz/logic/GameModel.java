package pvz.logic;

import pvz.control.Level;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.Zombie;
import utils.Position;

public interface GameModel extends GameWorld {
   
	void reset();
	void reset(Level level, long seed);
    void update();
    void quit();
	boolean playerQuits();
	boolean hasGameFinished();

	boolean addGameObject(String name, Position position);
    boolean addPlant(Plant plant);
	boolean addPlantCheat(Plant plant);
	boolean addZombie(Zombie zombie);
	boolean addGameObjectForFree(String name, Position position);

	boolean catchObject(Position position);

}
