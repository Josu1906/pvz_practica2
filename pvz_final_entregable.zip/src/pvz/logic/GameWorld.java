package pvz.logic;

import pvz.logic.actions.GameAction;
import pvz.logic.gameobjects.GameObject;
import utils.Position;

public interface GameWorld {

    int NUM_ROWS = 4;
    int NUM_COLS = 8;

    Position randomPosition();
    String positionToString(Position position);

    boolean isEmpty(Position position);
    boolean isInsideBoard(Position position);
    boolean isInBoardLimit(Position position);

    void generateCoins(int amount);
    void generateSun();

    boolean plantAttack(Position position, int damage);
    boolean zombieAttack(Position position, int damage);
    
    default boolean plantAttackInPosition(Position position, int damage) {
        return plantAttack(position, damage);
    }
    
    boolean addGameObject(GameObject object);

    void zombieKilled();
    void pushAction(GameAction action);
    
    default void zombieEntered() {
    }
}