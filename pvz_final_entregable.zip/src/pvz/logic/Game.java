package pvz.logic;
import java.util.Random;
import pvz.control.Level;
import pvz.logic.actions.GameAction;
import pvz.logic.gameobjects.*;
import utils.Position;
import pvz.logic.gameobjects.factories.PlantFactory;
import pvz.logic.gameobjects.factories.ZombieFactory;

import java.util.ArrayDeque;
import java.util.Deque;

public class Game implements GameModel, GameWorld, GameStatus{
	
	public static final int INITIAL_COINS=50;
	
	private GameObjectContainer objects;
	private ZombiesManager zombies;
	private SunsManager suns;
	
	private Random rand;
	private Level level;
	private long seed;
	
	private int cycles;
	private int coins;
	private int aliveZombies;
	private int caughtCoins;
	private int generatedCoins;
	
	private boolean caughtSunThisCycle;
	private boolean isThePlayerOut;
	
	private Deque<GameAction> actions;

	public Game(long seed, Level level) {
		this.level = level;
		this.seed=seed;
		reset();
	}
	
	@Override
	public void reset() {
		rand = new Random(seed);
        objects = new GameObjectContainer();
        zombies = new ZombiesManager(this, level, rand);
        suns = new SunsManager(this);
        
        cycles = 0;
        coins = INITIAL_COINS;
        aliveZombies = 0;
        caughtCoins = 0;
        generatedCoins = 0;
        
        caughtSunThisCycle = false;
        isThePlayerOut = false;
        
        actions = new ArrayDeque<>();
	}
	
	@Override
    public void reset(Level level, long seed) {
        this.level = level;
        this.seed = seed;
        reset();
    }
	
	@Override
	public Position randomPosition() {
	    int row = rand.nextInt(NUM_ROWS);
	    int column = rand.nextInt(NUM_COLS);

	    return new Position(row, column);
	}
	
	@Override
    public String positionToString(Position position) {
        return objects.positionToString(position);
    }
	
	public boolean isValidPosition(Position position) {
	    return isInsideBoard(position) && isEmpty(position);
	}
	 
	@Override
	public boolean isEmpty(Position position) {
	    return objects.isPositionEmpty(position);
	}
	

    public GameItem getGameItemInPosition(Position position) {
        return objects.getGameItemInPosition(position);
    }
	
	@Override
    public boolean isInsideBoard(Position position) {
        return position.row() >= 0
            && position.row() < NUM_ROWS
            && position.column() >= 0
            && position.column() < NUM_COLS;
    }
 
	@Override
	public boolean isInBoardLimit(Position position) {
	    return position.row() >= 0
	            && position.row() < NUM_ROWS
	            && position.column() >= -1
	            && position.column() <= NUM_COLS;
	}
	
	@Override
	public void generateCoins(int amount) {
		coins += amount;
	}
	
	
	@Override
	public int getCycles() {
		return cycles;
	}
	
	@Override
	public int getCoins() {
		return coins;
	}
	

    @Override
    public int getRemainingZombies() {
        return zombies.getRemainingZombies();
    }	
    
    public Position newZombiePosition(int row) {
        return new Position(row, NUM_COLS);
    }
    
    
    @Override
    public boolean addGameObject(GameObject object) {
        boolean added = object != null;
        if (added) {
            objects.add(object);
        }
        return added;
    }
    
    @Override
    public boolean addGameObject(String name, Position position) {
        Plant plant = PlantFactory.spawnPlant(name, this, position);
        boolean added;

        if (plant != null) {
            added = addPlant(plant);
        } else {
            Zombie zombie = ZombieFactory.spawnZombie(name, this, position);
            added = addZombie(zombie);
        }

        return added;
    }

    @Override
    public boolean addPlant(Plant plant) {
    	boolean added = plant != null
    	        && plant.canBeSpawnedAt(plant.getPosition())
    	        && coins >= plant.getCost();

        if (added) {
            coins -= plant.getCost();
            objects.add(plant);
        }

        return added;
    }

    @Override
    public void update() {
    	executePendingActions();
    	cycles++;
    	caughtSunThisCycle = false;
    	
        objects.removeDead();
        zombies.update();
        suns.update();
        objects.update();
        
        boolean deadRemoved = true;

        while (deadRemoved || arePendingActionsLeft()) {
            deadRemoved = objects.removeDead();
            executePendingActions();
        }    
    }

    @Override
    public void zombieEntered() {
        aliveZombies++;
    }

    @Override
    public void zombieKilled() {
        aliveZombies--;
    }
    
    @Override
    public boolean doZombiesReachedTheHouse() {
        return objects.anyInColumn(-1);
    }

    @Override
    public boolean playerWins() {
        return !doZombiesReachedTheHouse()
                && zombies.getRemainingZombies() == 0
                && aliveZombies == 0;
    }

    @Override
    public boolean hasGameFinished() {
        return playerQuits() || doZombiesReachedTheHouse() || playerWins();
    }

    @Override
    public void quit() {
        isThePlayerOut = true;
    }

    @Override
    public boolean playerQuits() {
        return isThePlayerOut;
    }
    
    @Override
    public void pushAction(GameAction action) {
        actions.addLast(action);
    }
    
    private void executePendingActions() {
        while (!actions.isEmpty()) {
            GameAction action = actions.removeFirst();
            action.execute(this);
        }
    }

    private boolean arePendingActionsLeft() {
        return !actions.isEmpty();
    }
    
    @Override
    public boolean addZombie(Zombie zombie) {
    	boolean added = zombie != null
    	        && zombie.canBeSpawnedAt(zombie.getPosition());
        if (added) {
            objects.add(zombie);
        }

        return added;
    }
    
    @Override
    public boolean addPlantCheat(Plant plant) {
    	boolean added = plant != null
    	        && plant.canBeSpawnedAt(plant.getPosition());
        if (added) {
            objects.add(plant);
        }

        return added;
    }
    
    public boolean addGameObjectForFree(String plantName, Position position) {
        Plant plant = PlantFactory.spawnPlant(plantName, this, position);
        return addPlantCheat(plant);
    }
    
    @Override
    public void generateSun() {
        suns.generateSun();
        generatedCoins++;
    }
    
    @Override
    public boolean catchObject(Position position) {
        boolean success = false;

        if (isInsideBoard(position) && !caughtSunThisCycle) {
            int collected = objects.catchObject(position);

            if (collected > 0) {
                caughtCoins += collected;
                caughtSunThisCycle = true;
                objects.removeDead();
                success = true;
            }
        }

        return success;
    }
    
    @Override
    public int getGeneratedCoins() {
        return generatedCoins;
    }

    @Override
    public int getCaughtCoins() {
        return caughtCoins;
    }
    
    @Override
    public boolean plantAttack(Position position, int damage) {
        boolean attacked = false;
        
        if (isInsideBoard(position)) {
            Position target = position.right();

            while (isInsideBoard(target) && !attacked) {
                GameItem item = getGameItemInPosition(target);
                if (item != null) {
                    attacked = item.receivePlantAttack(damage);
                }
                target = target.right();
            }
        }
        return attacked;
    }

    @Override
    public boolean zombieAttack(Position position, int damage) {
        GameItem item = getGameItemInPosition(position);
        boolean attacked = false;

        if (item != null) {
            attacked = item.receiveZombieAttack(damage);
        }

        return attacked;
    }
    
    @Override
    public boolean plantAttackInPosition(Position position, int damage) {
        boolean attacked = false;

        if (isInsideBoard(position)) {
            GameItem item = getGameItemInPosition(position);

            if (item != null) {
                attacked = item.receivePlantAttack(damage);
            }
        }

        return attacked;
    }
        
}
	
		



	
	