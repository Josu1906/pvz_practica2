package pvz.control.command;

import pvz.view.GameView;
import pvz.view.Messages;
import utils.Position;
import pvz.logic.GameModel;
import pvz.logic.gameobjects.Plant;
import pvz.logic.gameobjects.factories.PlantFactory;

public class AddPlantCommand extends Command {
	private String type_of_plant;
	private Position position;
	
	public AddPlantCommand() {
		super(Messages.COMMAND_ADD_PLANT_NAME, 
				Messages.COMMAND_ADD_PLANT_SHORTCUT, 
				Messages.COMMAND_ADD_PLANT_DETAILS, 
				Messages.COMMAND_ADD_PLANT_HELP);	
		
	}
	
	public AddPlantCommand(String type_of_plant, Position position) {
		super(Messages.COMMAND_ADD_PLANT_NAME, 
				Messages.COMMAND_ADD_PLANT_SHORTCUT, 
				Messages.COMMAND_ADD_PLANT_DETAILS, 
				Messages.COMMAND_ADD_PLANT_HELP);
		this.type_of_plant = type_of_plant;
		this.position = position;
		
	}
	
	@Override
	public Command create(String[] words) {
	    Command result;

	    if (words.length < 4) {
	        result = new ErrorCommand(Messages.COMMAND_PARAMETERS_MISSING);
	    } else if (words.length > 4) {
	        result = new ErrorCommand(Messages.INVALID_COMMAND);
	    } else {
	        String plantName = words[1];
	        int col = Integer.parseInt(words[2]);
	        int row = Integer.parseInt(words[3]);

	        result = new AddPlantCommand(plantName, new Position(row, col));
	    }

	    return result;
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
	    Plant plant = PlantFactory.spawnPlant(type_of_plant, game, position);

	    if (plant == null) {
	    	view.showError(Messages.INVALID_GAME_OBJECT);
	    } else if (!game.isInsideBoard(position)
	            || !game.isEmpty(position)) {
	    	view.showError(Messages.INVALID_POSITION);
	    } else if (game.addPlant(plant)) {
	        game.update();
	        view.showGame();
	    } else {
	    	view.showError(Messages.NOT_ENOUGH_COINS);
	    }
	}

}